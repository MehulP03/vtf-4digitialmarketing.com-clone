import React from 'react'
import RevealTry1 from './RevealTry1'
import RevealTry2 from './RevealTry2'
import RevealTry3 from './RevealTry3'
import RevealTry4 from './RevealTry4'
import RevealTry5 from './RevealTry5'
import RevealTry6 from './RevealTry6'
import RevealTry7 from './RevealTry7'
import RevealTry8 from './RevealTry8'
import RevealTry9 from './RevealTry9'
import RevealTry10 from './RevealTry10'
import RevealTry11 from './RevealTry11'
import RevealTry13 from './RevealTry13'
import RevealTry12 from './RevealTry12'


function LandingPage() {
  return (
    <> 
      <RevealTry1/>
      <RevealTry2/>
      <RevealTry3/>
      <RevealTry4/>
      <RevealTry5/>
      <RevealTry6/><hr style={{ border:'1px solid #f0f0f0' }} />
      <RevealTry7/>
      <RevealTry8/>
      <RevealTry9/>
      <RevealTry10/>
      <RevealTry11/>
      <RevealTry12/>
      <RevealTry13/>
    </>
  )
}

export default LandingPage